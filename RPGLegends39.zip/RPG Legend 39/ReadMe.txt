The Game is all about a hybred dugeon crawler. you fit each tiles doors together to place a tile. 

THE MOST IMPORTANT FACT, YOU NEED TO CLICK THE 4 DICE TO ROLL FOR ANYTHING IN THIS GAME, BEFORE YOU EVEN BEGIN EXPLORING YOU NEED TO ROLL ALL YOUR STATS.

There are skill throughs like a D20 RPG system - but with 4D6s. You roll for base stats and lowest die gets dropped, all the modifiers are the same as a D20 RPG system. every time you roll - you throw 4D6s + skill rank + modifier, to see if you suceed, if you fail you will have to pay the fail price and reroll.

the stats look like this STR [14/2] this means strength of 14 with a modifier of 2, what happens is you roll your stats, every 2 points above 10 you get a modifier bonus, its this bonus that gets added to your dice roll.

STR = STRENGTH  DEX = DEXTERITY  CON = CONSTITUTION  CHA = CHARISMA   INT = INTELIGENCE   WIZ  = WIZDOM.  these stats are associated to skills, when you roll a skill for example swim, the STR modifier(bonus) is added to your roll allong with how many skill points you have in swim.  the game rolls are easy to pass most of the time, but its the times you fail that cost for example in combat you lose hitpoints so buff up your combat skill, but there is a cap on combat skill of 3, and you must level-up and aquire new skill points to increase tour other skills

every tile has an associated skill roll to pass.

you can spend your skill points on any skill, the buttons next to the skills allow you to add points upto the Level cap. combat will never go above 3

you explore a dungeon looking for the door to the next level, once you get to a higher level, you get a higher cap on skill points, you still need to find new skills

the bottom left tile displays the next tile to be placed, you can click on it and roll for a better tile, but you will pay for it, the tile is then placed on the dungeon grid, but the doors must line-up together, or it will not place, this is part of the puzzle of exploring.

combat is just a matter of entering a shield tile and rolling for combat, but if you fail a roll your hitpoints will drop, if you lose all hit points you die.

the game uses VIGOUR for buying new tiles , but you can add or lose viguor as you play, you will really need it when you cant place a tile anywhere.

Collect all the gold you can

there are 2 ways you can lose, first you can run out of places to put tiles(so buy new tiles when you have vigour) 2) you can loose all your hitpoints in combat with monsters and dragons